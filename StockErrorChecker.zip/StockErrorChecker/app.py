from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
import os
from core.stock_tracker import StockPortfolioTracker
from core.utils import calculate_portfolio_metrics, create_portfolio_distribution_chart, format_date
import datetime

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', 'default_secret_key')

# Initialize the stock tracker
api_key = os.environ.get('ALPHAVANTAGE_API_KEY')
stock_tracker = StockPortfolioTracker(api_key=api_key)

@app.route('/')
def index():
    """Render the dashboard page with portfolio summary."""
    portfolio = stock_tracker.get_portfolio_summary()
    transactions = stock_tracker.get_transactions(limit=5)
    
    # Format dates in transactions
    for tx in transactions:
        tx['date'] = format_date(tx['date'])
    
    # Get portfolio performance chart
    portfolio_chart = stock_tracker.plot_portfolio_history(days=30)
    
    # Get asset allocation chart
    allocation_chart = stock_tracker.plot_asset_allocation()
    
    # Calculate additional portfolio metrics
    metrics = calculate_portfolio_metrics(portfolio)
    
    return render_template(
        'index.html', 
        portfolio=portfolio, 
        transactions=transactions, 
        portfolio_chart=portfolio_chart,
        allocation_chart=allocation_chart,
        metrics=metrics,
        cash=portfolio['cash']
    )

@app.route('/portfolio')
def portfolio():
    """Render the portfolio page with detailed holdings."""
    portfolio = stock_tracker.get_portfolio_summary()
    
    # Create distribution chart
    distribution_chart = create_portfolio_distribution_chart(portfolio)
    
    # Get owned stocks for the sell form
    owned_stocks = []
    for stock in portfolio['stocks']:
        owned_stocks.append({
            'symbol': stock['symbol'],
            'shares': stock['shares']
        })
    
    return render_template(
        'portfolio.html', 
        portfolio=portfolio, 
        distribution_chart=distribution_chart,
        owned_stocks=owned_stocks,
        cash=portfolio['cash']
    )

@app.route('/transactions')
def transactions():
    """Render the transactions history page."""
    filter_type = request.args.get('filter', 'all')
    
    if filter_type != 'all':
        transactions = stock_tracker.get_transactions(transaction_type=filter_type)
    else:
        transactions = stock_tracker.get_transactions()
    
    # Format dates
    for tx in transactions:
        tx['date'] = format_date(tx['date'])
    
    # Get owned stocks for the sell form
    portfolio = stock_tracker.get_portfolio_summary()
    owned_stocks = []
    for stock in portfolio['stocks']:
        owned_stocks.append({
            'symbol': stock['symbol'],
            'shares': stock['shares']
        })
    
    return render_template(
        'transactions.html', 
        transactions=transactions, 
        filter_type=filter_type,
        owned_stocks=owned_stocks,
        cash=portfolio['cash']
    )

@app.route('/analysis')
def analysis():
    """Render the portfolio analysis page."""
    period = int(request.args.get('period', 90))
    benchmark = request.args.get('benchmark', 'SPY')
    
    portfolio = stock_tracker.get_portfolio_summary()
    
    # Get performance analysis
    performance = stock_tracker.analyze_performance(benchmark=benchmark, days=period)
    
    # Get asset allocation chart
    allocation_chart = stock_tracker.plot_asset_allocation()
    
    # Get owned stocks for the sell form
    owned_stocks = []
    for stock in portfolio['stocks']:
        owned_stocks.append({
            'symbol': stock['symbol'],
            'shares': stock['shares']
        })
    
    return render_template(
        'analysis.html', 
        portfolio=portfolio,
        performance=performance,
        allocation_chart=allocation_chart,
        period=period,
        benchmark=benchmark,
        owned_stocks=owned_stocks,
        cash=portfolio['cash']
    )

@app.route('/stock/<symbol>')
def stock_detail(symbol):
    """Render detailed view for a specific stock."""
    # This would be implemented to show detailed stock information,
    # historical charts, news, etc. For now, redirect to portfolio.
    flash(f"Detailed stock view for {symbol} is not yet implemented.", "info")
    return redirect(url_for('portfolio'))

@app.route('/add_cash', methods=['POST'])
def add_cash():
    """Handle adding cash to the portfolio."""
    amount = request.form.get('amount')
    try:
        result = stock_tracker.add_cash(float(amount))
        if result['success']:
            flash(result['message'], 'success')
        else:
            flash(result['message'], 'danger')
    except ValueError:
        flash("Invalid amount format. Please enter a valid number.", 'danger')
    
    return redirect(request.referrer or url_for('index'))

@app.route('/withdraw_cash', methods=['POST'])
def withdraw_cash():
    """Handle withdrawing cash from the portfolio."""
    amount = request.form.get('amount')
    try:
        result = stock_tracker.withdraw_cash(float(amount))
        if result['success']:
            flash(result['message'], 'success')
        else:
            flash(result['message'], 'danger')
    except ValueError:
        flash("Invalid amount format. Please enter a valid number.", 'danger')
    
    return redirect(request.referrer or url_for('index'))

@app.route('/buy_stock', methods=['POST'])
def buy_stock():
    """Handle buying a stock for the portfolio."""
    symbol = request.form.get('symbol')
    shares = request.form.get('shares')
    price = request.form.get('price') or None
    
    if price:
        try:
            price = float(price)
        except ValueError:
            flash("Invalid price format. Please enter a valid number.", 'danger')
            return redirect(request.referrer or url_for('portfolio'))
    
    try:
        result = stock_tracker.buy_stock(symbol, float(shares), price)
        if result['success']:
            flash(result['message'], 'success')
        else:
            flash(result['message'], 'danger')
    except ValueError:
        flash("Invalid input format. Please check your values.", 'danger')
    
    return redirect(request.referrer or url_for('portfolio'))

@app.route('/sell_stock', methods=['POST'])
def sell_stock():
    """Handle selling a stock from the portfolio."""
    symbol = request.form.get('symbol')
    shares = request.form.get('shares')
    price = request.form.get('price') or None
    
    if price:
        try:
            price = float(price)
        except ValueError:
            flash("Invalid price format. Please enter a valid number.", 'danger')
            return redirect(request.referrer or url_for('portfolio'))
    
    try:
        result = stock_tracker.sell_stock(symbol, float(shares), price)
        if result['success']:
            flash(result['message'], 'success')
        else:
            flash(result['message'], 'danger')
    except ValueError:
        flash("Invalid input format. Please check your values.", 'danger')
    
    return redirect(request.referrer or url_for('portfolio'))

@app.route('/search_stock')
def search_stock():
    """API endpoint to search for stocks."""
    query = request.args.get('query', '')
    if len(query) < 1:
        return jsonify({"success": False, "message": "Search query is too short"})
    
    result = stock_tracker.search_stock(query)
    return jsonify(result)

@app.template_filter('format_date')
def _format_date(date_str):
    """Template filter to format dates."""
    return format_date(date_str)

@app.context_processor
def utility_processor():
    """Make utility functions available to templates."""
    def format_currency(value):
        """Format a number as currency."""
        try:
            return "${:,.2f}".format(float(value))
        except (ValueError, TypeError):
            return "$0.00"
    
    def format_percentage(value):
        """Format a number as percentage."""
        try:
            return "{:.2f}%".format(float(value))
        except (ValueError, TypeError):
            return "0.00%"
            
    return dict(
        format_currency=format_currency,
        format_percentage=format_percentage
    )

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
