import requests
import json
import pandas as pd
import matplotlib.pyplot as plt
from datetime import datetime, timedelta
import os
from tabulate import tabulate
import time
import argparse

class StockPortfolioTracker:
    def __init__(self, api_key=None):
        """Initialize the Stock Portfolio Tracker."""
        # If no API key is provided, try to get it from environment variables
        self.api_key = api_key or os.environ.get('ALPHAVANTAGE_API_KEY')
        if not self.api_key:
            print("Warning: No API key provided. Please set ALPHAVANTAGE_API_KEY environment variable or provide it as an argument.")
            print("Get a free API key at: https://www.alphavantage.co/support/#api-key")
        
        self.portfolio_file = "portfolio.json"
        self.portfolio = self._load_portfolio()
        
    def _load_portfolio(self):
        """Load portfolio from file or create a new one if it doesn't exist."""
        try:
            with open(self.portfolio_file, 'r') as f:
                return json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            return {"stocks": {}, "cash": 0, "transactions": []}
    
    def _save_portfolio(self):
        """Save portfolio to file."""
        with open(self.portfolio_file, 'w') as f:
            json.dump(self.portfolio, f, indent=4)
    
    def add_cash(self, amount):
        """Add cash to the portfolio."""
        self.portfolio["cash"] += amount
        self.portfolio["transactions"].append({
            "type": "cash_deposit",
            "amount": amount,
            "date": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        })
        self._save_portfolio()
        print(f"Added ${amount:.2f} to portfolio. New cash balance: ${self.portfolio['cash']:.2f}")
    
    def withdraw_cash(self, amount):
        """Withdraw cash from the portfolio."""
        if amount > self.portfolio["cash"]:
            print(f"Error: Insufficient funds. Current cash balance: ${self.portfolio['cash']:.2f}")
            return False
        
        self.portfolio["cash"] -= amount
        self.portfolio["transactions"].append({
            "type": "cash_withdrawal",
            "amount": amount,
            "date": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        })
        self._save_portfolio()
        print(f"Withdrew ${amount:.2f} from portfolio. New cash balance: ${self.portfolio['cash']:.2f}")
        return True
    
    def get_stock_price(self, symbol):
        """Get current stock price from Alpha Vantage API."""
        if not self.api_key:
            # Use mock data if no API key
            import random
            return round(random.uniform(50, 500), 2)
        
        url = f"https://www.alphavantage.co/query?function=GLOBAL_QUOTE&symbol={symbol}&apikey={self.api_key}"
        try:
            response = requests.get(url)
            data = response.json()
            
            if "Global Quote" in data and "05. price" in data["Global Quote"]:
                return float(data["Global Quote"]["05. price"])
            else:
                print(f"Error fetching price for {symbol}: {data.get('Note', 'Unknown error')}")
                return None
        except Exception as e:
            print(f"Error fetching stock price for {symbol}: {e}")
            return None
    
    def buy_stock(self, symbol, shares, price=None):
        """Buy stocks and add them to the portfolio."""
        symbol = symbol.upper()
        
        # Get current price if not provided
        if price is None:
            price = self.get_stock_price(symbol)
            if price is None:
                return False
        
        total_cost = price * shares
        
        # Check if we have enough cash
        if total_cost > self.portfolio["cash"]:
            print(f"Error: Insufficient funds. Cost: ${total_cost:.2f}, Available: ${self.portfolio['cash']:.2f}")
            return False
        
        # Update cash
        self.portfolio["cash"] -= total_cost
        
        # Update portfolio
        if symbol in self.portfolio["stocks"]:
            # Calculate new average cost
            current_shares = self.portfolio["stocks"][symbol]["shares"]
            current_cost = self.portfolio["stocks"][symbol]["average_cost"]
            total_shares = current_shares + shares
            new_average_cost = ((current_shares * current_cost) + (shares * price)) / total_shares
            
            self.portfolio["stocks"][symbol]["shares"] = total_shares
            self.portfolio["stocks"][symbol]["average_cost"] = new_average_cost
        else:
            self.portfolio["stocks"][symbol] = {
                "shares": shares,
                "average_cost": price
            }
        
        # Record transaction
        self.portfolio["transactions"].append({
            "type": "buy",
            "symbol": symbol,
            "shares": shares,
            "price": price,
            "total": total_cost,
            "date": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        })
        
        self._save_portfolio()
        print(f"Bought {shares} shares of {symbol} at ${price:.2f} per share (Total: ${total_cost:.2f})")
        return True
    
    def sell_stock(self, symbol, shares, price=None):
        """Sell stocks from the portfolio."""
        symbol = symbol.upper()
        
        # Check if we have the stock and enough shares
        if symbol not in self.portfolio["stocks"]:
            print(f"Error: You don't own any shares of {symbol}")
            return False
        
        if shares > self.portfolio["stocks"][symbol]["shares"]:
            print(f"Error: You only have {self.portfolio['stocks'][symbol]['shares']} shares of {symbol}")
            return False
        
        # Get current price if not provided
        if price is None:
            price = self.get_stock_price(symbol)
            if price is None:
                return False
        
        total_value = price * shares
        
        # Update cash
        self.portfolio["cash"] += total_value
        
        # Update portfolio
        self.portfolio["stocks"][symbol]["shares"] -= shares
        
        # Remove stock if no shares left
        if self.portfolio["stocks"][symbol]["shares"] == 0:
            del self.portfolio["stocks"][symbol]
        
        # Record transaction
        self.portfolio["transactions"].append({
            "type": "sell",
            "symbol": symbol,
            "shares": shares,
            "price": price,
            "total": total_value,
            "date": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        })
        
        self._save_portfolio()
        print(f"Sold {shares} shares of {symbol} at ${price:.2f} per share (Total: ${total_value:.2f})")
        return True
    
    def get_historical_data(self, symbol, days=30):
        """Get historical stock data for the specified symbol."""
        if not self.api_key:
            # Generate mock data if no API key
            dates = [(datetime.now() - timedelta(days=i)).strftime('%Y-%m-%d') for i in range(days, 0, -1)]
            import random
            starting_price = random.uniform(50, 500)
            prices = [round(starting_price * (1 + random.uniform(-0.05, 0.05) * i), 2) for i in range(days)]
            return pd.DataFrame({'date': dates, 'close': prices})
        
        end_date = datetime.now()
        start_date = end_date - timedelta(days=days)
        
        url = f"https://www.alphavantage.co/query?function=TIME_SERIES_DAILY&symbol={symbol}&outputsize=full&apikey={self.api_key}"
        
        try:
            response = requests.get(url)
            data = response.json()
            
            if "Time Series (Daily)" in data:
                time_series = data["Time Series (Daily)"]
                df = pd.DataFrame(time_series).T
                df.index = pd.to_datetime(df.index)
                df = df.sort_index()
                
                # Rename columns and convert to numeric
                df.columns = ['open', 'high', 'low', 'close', 'volume']
                for col in df.columns:
                    df[col] = pd.to_numeric(df[col])
                
                # Filter by date range
                df = df[(df.index >= start_date.strftime('%Y-%m-%d')) & 
                        (df.index <= end_date.strftime('%Y-%m-%d'))]
                
                # Reset index to make date a column
                df = df.reset_index()
                df.rename(columns={'index': 'date'}, inplace=True)
                
                return df
            else:
                print(f"Error fetching historical data for {symbol}: {data.get('Note', 'Unknown error')}")
                return None
                
        except Exception as e:
            print(f"Error fetching historical data for {symbol}: {e}")
            return None
    
    def show_portfolio(self):
        """Display the current portfolio status."""
        if not self.portfolio["stocks"] and self.portfolio["cash"] == 0:
            print("Portfolio is empty.")
            return
        
        print("\n===== PORTFOLIO SUMMARY =====")
        print(f"Cash: ${self.portfolio['cash']:.2f}")
        
        if not self.portfolio["stocks"]:
            print("No stocks in portfolio.")
            return
        
        # Fetch current prices and calculate values
        portfolio_data = []
        total_value = self.portfolio["cash"]
        total_cost = 0
        
        for symbol, data in self.portfolio["stocks"].items():
            shares = data["shares"]
            avg_cost = data["average_cost"]
            cost_basis = shares * avg_cost
            total_cost += cost_basis
            
            current_price = self.get_stock_price(symbol)
            if current_price is None:
                current_price = avg_cost  # Use average cost if can't get current price
            
            current_value = shares * current_price
            total_value += current_value
            
            gain_loss = current_value - cost_basis
            gain_loss_pct = (gain_loss / cost_basis) * 100 if cost_basis > 0 else 0
            
            portfolio_data.append([
                symbol,
                shares,
                f"${avg_cost:.2f}",
                f"${cost_basis:.2f}",
                f"${current_price:.2f}",
                f"${current_value:.2f}",
                f"${gain_loss:.2f}",
                f"{gain_loss_pct:.2f}%"
            ])
        
        # Sort by value (descending)
        portfolio_data.sort(key=lambda x: float(x[5].replace('$', '')), reverse=True)
        
        headers = ["Symbol", "Shares", "Avg Cost", "Cost Basis", "Current Price", "Current Value", "Gain/Loss", "Gain/Loss %"]
        print(tabulate(portfolio_data, headers=headers, tablefmt="grid"))
        
        # Show totals
        total_gain_loss = total_value - total_cost - self.portfolio["cash"]
        total_gain_loss_pct = (total_gain_loss / (total_cost)) * 100 if total_cost > 0 else 0
        
        print("\n===== PORTFOLIO TOTALS =====")
        print(f"Total Cost Basis: ${total_cost:.2f}")
        print(f"Total Current Value: ${total_value:.2f} (including ${self.portfolio['cash']:.2f} cash)")
        print(f"Total Gain/Loss: ${total_gain_loss:.2f} ({total_gain_loss_pct:.2f}%)")
    
    def plot_portfolio_history(self, days=30):
        """Plot the historical performance of the portfolio."""
        if not self.portfolio["stocks"]:
            print("No stocks in portfolio to plot.")
            return
        
        end_date = datetime.now()
        start_date = end_date - timedelta(days=days)
        
        date_range = pd.date_range(start=start_date, end=end_date)
        portfolio_history = pd.DataFrame(index=date_range)
        portfolio_history.index.name = 'date'
        portfolio_history['total_value'] = 0
        
        # Add cash to total value
        portfolio_history['total_value'] += self.portfolio["cash"]
        
        # Process each stock
        for symbol, data in self.portfolio["stocks"].items():
            shares = data["shares"]
            historical_data = self.get_historical_data(symbol, days=days)
            
            if historical_data is not None:
                historical_data['date'] = pd.to_datetime(historical_data['date'])
                historical_data.set_index('date', inplace=True)
                
                # Make sure the index is unique
                historical_data = historical_data[~historical_data.index.duplicated(keep='first')]
                
                # Reindex to full date range and forward fill
                stock_data = pd.DataFrame(index=date_range)
                stock_data = stock_data.join(historical_data[['close']])
                stock_data['close'] = stock_data['close'].fillna(method='ffill')
                
                # Calculate value and add to portfolio
                stock_data['value'] = stock_data['close'] * shares
                portfolio_history['total_value'] += stock_data['value'].fillna(0)
        
        # Plot the portfolio value over time
        plt.figure(figsize=(12, 6))
        plt.plot(portfolio_history.index, portfolio_history['total_value'], 'b-')
        plt.title('Portfolio Value Over Time')
        plt.xlabel('Date')
        plt.ylabel('Value ($)')
        plt.grid(True)
        plt.tight_layout()
        
        # Save the plot to a file
        plt.savefig('portfolio_history.png')
        print("Portfolio history plot saved as 'portfolio_history.png'")
        plt.close()
    
    def show_transactions(self, limit=10):
        """Display recent transactions."""
        if not self.portfolio["transactions"]:
            print("No transactions recorded.")
            return
        
        print(f"\n===== RECENT TRANSACTIONS (Last {min(limit, len(self.portfolio['transactions']))}) =====")
        
        transactions = self.portfolio["transactions"][-limit:]  # Get most recent transactions
        
        transaction_data = []
        for t in reversed(transactions):  # Display most recent first
            if t["type"] == "buy":
                transaction_data.append([
                    t["date"],
                    "BUY",
                    t["symbol"],
                    t["shares"],
                    f"${t['price']:.2f}",
                    f"${t['total']:.2f}"
                ])
            elif t["type"] == "sell":
                transaction_data.append([
                    t["date"],
                    "SELL",
                    t["symbol"],
                    t["shares"],
                    f"${t['price']:.2f}",
                    f"${t['total']:.2f}"
                ])
            elif t["type"] == "cash_deposit":
                transaction_data.append([
                    t["date"],
                    "DEPOSIT",
                    "-",
                    "-",
                    "-",
                    f"${t['amount']:.2f}"
                ])
            elif t["type"] == "cash_withdrawal":
                transaction_data.append([
                    t["date"],
                    "WITHDRAW",
                    "-",
                    "-",
                    "-",
                    f"${t['amount']:.2f}"
                ])
        
        headers = ["Date", "Type", "Symbol", "Shares", "Price", "Total"]
        print(tabulate(transaction_data, headers=headers, tablefmt="grid"))

    def analyze_portfolio(self):
        """Analyze portfolio for diversification and risk."""
        if not self.portfolio["stocks"]:
            print("No stocks in portfolio to analyze.")
            return
            
        print("\n===== PORTFOLIO ANALYSIS =====")
        
        # Calculate portfolio diversification
        total_value = sum(self.get_stock_price(symbol) * data["shares"] 
                          for symbol, data in self.portfolio["stocks"].items() 
                          if self.get_stock_price(symbol) is not None)
        
        print("Asset Allocation:")
        allocations = []
        
        for symbol, data in self.portfolio["stocks"].items():
            current_price = self.get_stock_price(symbol)
            if current_price is not None:
                value = current_price * data["shares"]
                percentage = (value / total_value) * 100
                allocations.append([symbol, f"${value:.2f}", f"{percentage:.2f}%"])
        
        # Sort by allocation (descending)
        allocations.sort(key=lambda x: float(x[1].replace('$', '')), reverse=True)
        
        headers = ["Symbol", "Value", "Allocation %"]
        print(tabulate(allocations, headers=headers, tablefmt="grid"))
        
        # Calculate concentration risk
        largest_allocation = float(allocations[0][2].replace('%', '')) if allocations else 0
        
        print("\nConcentration Analysis:")
        if largest_allocation > 30:
            print(f"Warning: High concentration risk. Your largest position ({allocations[0][0]}) represents {allocations[0][2]} of your portfolio.")
        elif largest_allocation > 20:
            print(f"Moderate concentration risk. Your largest position ({allocations[0][0]}) represents {allocations[0][2]} of your portfolio.")
        else:
            print("Good diversification. No single position represents more than 20% of your portfolio.")
            
        # Cash position analysis
        cash_percentage = (self.portfolio["cash"] / (total_value + self.portfolio["cash"])) * 100 if (total_value + self.portfolio["cash"]) > 0 else 0
        print(f"\nCash Position: ${self.portfolio['cash']:.2f} ({cash_percentage:.2f}% of total portfolio)")
        
        if cash_percentage > 30:
            print("Note: Large cash position may be underutilized. Consider additional investments.")
        elif cash_percentage < 5 and cash_percentage > 0:
            print("Note: Low cash position. Consider maintaining some cash for opportunities or emergencies.")


def main():
    parser = argparse.ArgumentParser(description='Stock Portfolio Tracker')
    parser.add_argument('--api_key', type=str, help='Alpha Vantage API Key (or set ALPHAVANTAGE_API_KEY environment variable)')
    
    subparsers = parser.add_subparsers(dest='command', help='Command to execute')
    
    # Add cash command
    add_cash_parser = subparsers.add_parser('add_cash', help='Add cash to portfolio')
    add_cash_parser.add_argument('amount', type=float, help='Amount of cash to add')
    
    # Withdraw cash command
    withdraw_cash_parser = subparsers.add_parser('withdraw_cash', help='Withdraw cash from portfolio')
    withdraw_cash_parser.add_argument('amount', type=float, help='Amount of cash to withdraw')
    
    # Buy stock command
    buy_parser = subparsers.add_parser('buy', help='Buy stock')
    buy_parser.add_argument('symbol', type=str, help='Stock symbol')
    buy_parser.add_argument('shares', type=float, help='Number of shares to buy')
    buy_parser.add_argument('--price', type=float, help='Price per share (optional, will use current market price if not provided)')
    
    # Sell stock command
    sell_parser = subparsers.add_parser('sell', help='Sell stock')
    sell_parser.add_argument('symbol', type=str, help='Stock symbol')
    sell_parser.add_argument('shares', type=float, help='Number of shares to sell')
    sell_parser.add_argument('--price', type=float, help='Price per share (optional, will use current market price if not provided)')
    
    # Portfolio command
    subparsers.add_parser('portfolio', help='Show portfolio')
    
    # Transactions command
    transactions_parser = subparsers.add_parser('transactions', help='Show recent transactions')
    transactions_parser.add_argument('--limit', type=int, default=10, help='Number of transactions to show')
    
    # Plot command
    plot_parser = subparsers.add_parser('plot', help='Plot portfolio history')
    plot_parser.add_argument('--days', type=int, default=30, help='Number of days to plot')
    
    # Analyze command
    subparsers.add_parser('analyze', help='Analyze portfolio')
    
    args = parser.parse_args()
    
    # Create portfolio tracker
    tracker = StockPortfolioTracker(api_key=args.api_key)
    
    # Execute command
    if args.command == 'add_cash':
        tracker.add_cash(args.amount)
    elif args.command == 'withdraw_cash':
        tracker.withdraw_cash(args.amount)
    elif args.command == 'buy':
        tracker.buy_stock(args.symbol, args.shares, args.price)
    elif args.command == 'sell':
        tracker.sell_stock(args.symbol, args.shares, args.price)
    elif args.command == 'portfolio':
        tracker.show_portfolio()
    elif args.command == 'transactions':
        tracker.show_transactions(args.limit)
    elif args.command == 'plot':
        tracker.plot_portfolio_history(args.days)
    elif args.command == 'analyze':
        tracker.analyze_portfolio()
    else:
        # Interactive mode
        print("\nStock Portfolio Tracker")
        print("=====================")
        print("1. Show Portfolio")
        print("2. Buy Stock")
        print("3. Sell Stock")
        print("4. Add Cash")
        print("5. Withdraw Cash")
        print("6. Show Recent Transactions")
        print("7. Plot Portfolio History")
        print("8. Analyze Portfolio")
        print("9. Exit")
        
        while True:
            choice = input("\nEnter your choice (1-9): ")
            
            if choice == '1':
                tracker.show_portfolio()
            elif choice == '2':
                symbol = input("Enter stock symbol: ").upper()
                shares = float(input("Enter number of shares: "))
                tracker.buy_stock(symbol, shares)
            elif choice == '3':
                symbol = input("Enter stock symbol: ").upper()
                shares = float(input("Enter number of shares: "))
                tracker.sell_stock(symbol, shares)
            elif choice == '4':
                amount = float(input("Enter amount to add: "))
                tracker.add_cash(amount)
            elif choice == '5':
                amount = float(input("Enter amount to withdraw: "))
                tracker.withdraw_cash(amount)
            elif choice == '6':
                limit = int(input("Enter number of transactions to show: "))
                tracker.show_transactions(limit)
            elif choice == '7':
                days = int(input("Enter number of days to plot: "))
                tracker.plot_portfolio_history(days)
            elif choice == '8':
                tracker.analyze_portfolio()
            elif choice == '9':
                print("Thank you for using Stock Portfolio Tracker!")
                break
            else:
                print("Invalid choice. Please try again.")


if __name__ == "__main__":
    main()