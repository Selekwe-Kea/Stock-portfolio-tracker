document.addEventListener('DOMContentLoaded', function() {
    // Initialize Feather icons
    if (typeof feather !== 'undefined') {
        feather.replace();
    }
    
    // Set up search functionality
    setupStockSearch();
    
    // Dynamic form validation
    setupFormValidation();
    
    // Initialize tooltips
    initializeTooltips();
});

function setupStockSearch() {
    const searchButton = document.getElementById('searchButton');
    const searchQuery = document.getElementById('searchQuery');
    const searchResults = document.getElementById('searchResults');
    
    if (searchButton && searchQuery && searchResults) {
        searchButton.addEventListener('click', function() {
            const query = searchQuery.value.trim();
            if (query.length < 1) return;
            
            // Show loading indicator
            searchResults.innerHTML = '<div class="text-center py-3"><div class="loading-spinner"></div><p class="mt-2">Searching...</p></div>';
            
            // Fetch search results
            fetch(`/search_stock?query=${encodeURIComponent(query)}`)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        if (data.results.length > 0) {
                            let resultsHtml = '<div class="list-group">';
                            data.results.forEach(stock => {
                                resultsHtml += `
                                    <div class="list-group-item result-item">
                                        <div class="d-flex w-100 justify-content-between">
                                            <h5 class="mb-1">${stock.symbol}</h5>
                                            <small>${stock.region}</small>
                                        </div>
                                        <p class="mb-1">${stock.name}</p>
                                        <div class="d-flex justify-content-between align-items-center">
                                            <small>${stock.type} • ${stock.currency}</small>
                                            <div class="btn-group">
                                                <button class="btn btn-sm btn-success buy-btn" data-symbol="${stock.symbol}">Buy</button>
                                                <button class="btn btn-sm btn-info info-btn" data-symbol="${stock.symbol}">Info</button>
                                            </div>
                                        </div>
                                    </div>
                                `;
                            });
                            resultsHtml += '</div>';
                            searchResults.innerHTML = resultsHtml;
                            
                            // Add event listeners to buttons
                            document.querySelectorAll('.buy-btn').forEach(btn => {
                                btn.addEventListener('click', function() {
                                    const symbol = this.getAttribute('data-symbol');
                                    document.getElementById('buySymbol').value = symbol;
                                    var searchModal = bootstrap.Modal.getInstance(document.getElementById('searchStockModal'));
                                    searchModal.hide();
                                    var buyModal = new bootstrap.Modal(document.getElementById('buyStockModal'));
                                    buyModal.show();
                                });
                            });
                            
                            document.querySelectorAll('.info-btn').forEach(btn => {
                                btn.addEventListener('click', function() {
                                    const symbol = this.getAttribute('data-symbol');
                                    window.location.href = `/stock/${symbol}`;
                                });
                            });
                        } else {
                            searchResults.innerHTML = '<div class="alert alert-info">No results found for your search.</div>';
                        }
                    } else {
                        searchResults.innerHTML = `<div class="alert alert-danger">${data.message}</div>`;
                    }
                })
                .catch(error => {
                    console.error('Error searching stocks:', error);
                    searchResults.innerHTML = '<div class="alert alert-danger">An error occurred while searching. Please try again later.</div>';
                });
        });
        
        // Allow pressing Enter to search
        searchQuery.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                searchButton.click();
                e.preventDefault();
            }
        });
    }
}

function setupFormValidation() {
    // Buy stock form validation
    const buyForm = document.querySelector('form[action="/buy_stock"]');
    if (buyForm) {
        buyForm.addEventListener('submit', function(e) {
            const symbol = document.getElementById('buySymbol').value.trim();
            const shares = parseFloat(document.getElementById('buyShares').value);
            const price = document.getElementById('buyPrice').value.trim();
            
            if (!symbol) {
                alert('Please enter a stock symbol.');
                e.preventDefault();
                return false;
            }
            
            if (isNaN(shares) || shares <= 0) {
                alert('Please enter a valid number of shares greater than zero.');
                e.preventDefault();
                return false;
            }
            
            if (price && (isNaN(parseFloat(price)) || parseFloat(price) <= 0)) {
                alert('Price must be a positive number.');
                e.preventDefault();
                return false;
            }
            
            return true;
        });
    }
    
    // Sell stock form validation
    const sellForm = document.querySelector('form[action="/sell_stock"]');
    if (sellForm) {
        sellForm.addEventListener('submit', function(e) {
            const symbol = document.getElementById('sellSymbol').value;
            const shares = parseFloat(document.getElementById('sellShares').value);
            const price = document.getElementById('sellPrice').value.trim();
            
            if (!symbol || symbol === "") {
                alert('Please select a stock to sell.');
                e.preventDefault();
                return false;
            }
            
            if (isNaN(shares) || shares <= 0) {
                alert('Please enter a valid number of shares greater than zero.');
                e.preventDefault();
                return false;
            }
            
            if (price && (isNaN(parseFloat(price)) || parseFloat(price) <= 0)) {
                alert('Price must be a positive number.');
                e.preventDefault();
                return false;
            }
            
            return true;
        });
    }
    
    // Cash transaction validation
    const cashForms = document.querySelectorAll('form[action="/add_cash"], form[action="/withdraw_cash"]');
    cashForms.forEach(form => {
        form.addEventListener('submit', function(e) {
            const amount = parseFloat(this.querySelector('input[name="amount"]').value);
            
            if (isNaN(amount) || amount <= 0) {
                alert('Please enter a valid amount greater than zero.');
                e.preventDefault();
                return false;
            }
            
            return true;
        });
    });
}

function initializeTooltips() {
    // Initialize Bootstrap tooltips if available
    if (typeof bootstrap !== 'undefined' && bootstrap.Tooltip) {
        const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
        tooltipTriggerList.map(function(tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });
    }
}

// Function to update the cash value in the buy stock modal
function updateAvailableCash(cash) {
    const cashElement = document.getElementById('availableCash');
    if (cashElement) {
        cashElement.textContent = `$${parseFloat(cash).toFixed(2)}`;
    }
}

// Function to prepare the sell stock dropdown
function updateSellOptions(stocks) {
    const sellSymbol = document.getElementById('sellSymbol');
    if (sellSymbol) {
        // Clear existing options
        sellSymbol.innerHTML = '<option value="" selected disabled>Select a stock</option>';
        
        // Add options for each stock
        stocks.forEach(stock => {
            const option = document.createElement('option');
            option.value = stock.symbol;
            option.textContent = `${stock.symbol} (${stock.shares} shares)`;
            sellSymbol.appendChild(option);
        });
    }
}

// Update max shares when stock is selected in sell form
document.addEventListener('DOMContentLoaded', function() {
    const sellSymbol = document.getElementById('sellSymbol');
    const sellShares = document.getElementById('sellShares');
    
    if (sellSymbol && sellShares) {
        sellSymbol.addEventListener('change', function() {
            const selected = this.options[this.selectedIndex];
            if (selected && selected.value) {
                const matches = selected.textContent.match(/\(([^)]+)\)/);
                if (matches && matches[1]) {
                    const sharesText = matches[1].replace(' shares', '');
                    const maxShares = parseFloat(sharesText);
                    sellShares.max = maxShares;
                    sellShares.placeholder = `Max: ${maxShares}`;
                }
            }
        });
    }
});
