import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import matplotlib.pyplot as plt
from matplotlib.figure import Figure
from matplotlib.backends.backend_agg import FigureCanvasAgg as FigureCanvas
import io
import base64

def format_currency(value):
    """Format a number as currency."""
    return f"${value:,.2f}"

def format_percentage(value):
    """Format a number as percentage."""
    return f"{value:.2f}%"

def format_date(date_str):
    """Format a date string to a more readable format."""
    try:
        date_obj = datetime.strptime(date_str, "%Y-%m-%d %H:%M:%S")
        return date_obj.strftime("%b %d, %Y %I:%M %p")
    except:
        return date_str

def calculate_portfolio_metrics(portfolio_data):
    """Calculate various portfolio metrics."""
    if not portfolio_data or not portfolio_data.get('stocks'):
        return {
            'diversification_score': 0,
            'risk_level': 'N/A',
            'largest_position': 'None',
            'largest_position_pct': 0
        }
    
    total_value = portfolio_data['total_value']
    
    # Calculate position weights
    weights = []
    symbols = []
    for stock in portfolio_data['stocks']:
        weight = stock['current_value'] / total_value if total_value > 0 else 0
        weights.append(weight)
        symbols.append(stock['symbol'])
    
    # Get largest position
    if weights:
        max_weight_idx = weights.index(max(weights))
        largest_position = symbols[max_weight_idx]
        largest_position_pct = weights[max_weight_idx] * 100
    else:
        largest_position = 'None'
        largest_position_pct = 0
    
    # Diversification score (0-100)
    # Higher when more evenly distributed
    if len(weights) > 1:
        # Herfindahl-Hirschman Index (HHI)
        hhi = sum([w**2 for w in weights])
        # Normalize to 0-100 scale (inverted so higher is more diversified)
        diversification_score = 100 * (1 - (hhi - 1/len(weights)) / (1 - 1/len(weights)))
    else:
        diversification_score = 0
    
    # Risk level based on diversification
    if diversification_score > 80:
        risk_level = 'Low'
    elif diversification_score > 50:
        risk_level = 'Moderate'
    elif diversification_score > 30:
        risk_level = 'High'
    else:
        risk_level = 'Very High'
    
    return {
        'diversification_score': diversification_score,
        'risk_level': risk_level,
        'largest_position': largest_position,
        'largest_position_pct': largest_position_pct
    }

def create_portfolio_distribution_chart(portfolio_data):
    """Create a horizontal bar chart showing portfolio distribution."""
    if not portfolio_data or not portfolio_data.get('stocks'):
        return None
    
    # Extract data
    symbols = []
    values = []
    colors = []
    
    # Add cash
    symbols.append('Cash')
    values.append(portfolio_data['cash'])
    colors.append('#4CAF50')  # Green for cash
    
    # Add stocks
    for stock in portfolio_data['stocks']:
        symbols.append(stock['symbol'])
        values.append(stock['current_value'])
        
        # Color based on performance
        if stock['gain_loss'] > 0:
            colors.append('#2196F3')  # Blue for gain
        else:
            colors.append('#F44336')  # Red for loss
    
    # Create the plot
    fig = Figure(figsize=(10, max(4, len(symbols) * 0.4)))
    ax = fig.add_subplot(111)
    
    # Create horizontal bar chart
    y_pos = np.arange(len(symbols))
    ax.barh(y_pos, values, align='center', color=colors)
    
    # Add labels
    ax.set_yticks(y_pos)
    ax.set_yticklabels(symbols)
    ax.invert_yaxis()  # Stocks at the top
    
    # Add values as text
    total = sum(values)
    for i, v in enumerate(values):
        percentage = (v / total) * 100 if total > 0 else 0
        ax.text(v + 0.1, i, f"${v:,.2f} ({percentage:.1f}%)", va='center')
    
    ax.set_title('Portfolio Distribution')
    ax.set_xlabel('Value ($)')
    
    # Remove the frame
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    
    # Convert plot to PNG image
    canvas = FigureCanvas(fig)
    buf = io.BytesIO()
    canvas.print_png(buf)
    buf.seek(0)
    
    # Convert PNG to base64 string
    img_str = base64.b64encode(buf.read()).decode('utf-8')
    
    return img_str
