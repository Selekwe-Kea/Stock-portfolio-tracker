import requests
import json
import pandas as pd
import matplotlib.pyplot as plt
from datetime import datetime, timedelta
import os
import time
import io
import base64
from matplotlib.figure import Figure
from matplotlib.backends.backend_agg import FigureCanvasAgg as FigureCanvas
import numpy as np

class StockPortfolioTracker:
    def __init__(self, api_key=None, portfolio_file="portfolio.json"):
        """Initialize the Stock Portfolio Tracker."""
        # If no API key is provided, try to get it from environment variables
        self.api_key = api_key or os.environ.get('ALPHAVANTAGE_API_KEY')
        if not self.api_key:
            print("Warning: No API key provided. Please set ALPHAVANTAGE_API_KEY environment variable or provide it as an argument.")
            print("Get a free API key at: https://www.alphavantage.co/support/#api-key")
        
        self.portfolio_file = portfolio_file
        self.portfolio = self._load_portfolio()
        self.api_calls = 0
        self.last_api_call = 0
        
    def _load_portfolio(self):
        """Load portfolio from file or create a new one if it doesn't exist."""
        try:
            with open(self.portfolio_file, 'r') as f:
                return json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            return {"stocks": {}, "cash": 0, "transactions": [], "created_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
    
    def _save_portfolio(self):
        """Save portfolio to file."""
        with open(self.portfolio_file, 'w') as f:
            json.dump(self.portfolio, f, indent=4)
    
    def _throttle_api_calls(self):
        """Throttle API calls to prevent exceeding limits."""
        now = time.time()
        # Alpha Vantage free tier allows 5 calls per minute and 500 calls per day
        if now - self.last_api_call < 12:  # Wait at least 12 seconds between calls
            time.sleep(12 - (now - self.last_api_call))
        self.last_api_call = time.time()
        self.api_calls += 1
    
    def add_cash(self, amount):
        """Add cash to the portfolio."""
        try:
            amount = float(amount)
            if amount <= 0:
                return {"success": False, "message": "Amount must be greater than zero."}
            
            self.portfolio["cash"] += amount
            self.portfolio["transactions"].append({
                "type": "cash_deposit",
                "amount": amount,
                "date": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            })
            self._save_portfolio()
            return {
                "success": True, 
                "message": f"Added ${amount:.2f} to portfolio. New cash balance: ${self.portfolio['cash']:.2f}"
            }
        except ValueError:
            return {"success": False, "message": "Invalid amount format. Please enter a valid number."}
    
    def withdraw_cash(self, amount):
        """Withdraw cash from the portfolio."""
        try:
            amount = float(amount)
            if amount <= 0:
                return {"success": False, "message": "Amount must be greater than zero."}
                
            if amount > self.portfolio["cash"]:
                return {
                    "success": False, 
                    "message": f"Insufficient funds. Current cash balance: ${self.portfolio['cash']:.2f}"
                }
            
            self.portfolio["cash"] -= amount
            self.portfolio["transactions"].append({
                "type": "cash_withdrawal",
                "amount": amount,
                "date": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            })
            self._save_portfolio()
            return {
                "success": True, 
                "message": f"Withdrew ${amount:.2f} from portfolio. New cash balance: ${self.portfolio['cash']:.2f}"
            }
        except ValueError:
            return {"success": False, "message": "Invalid amount format. Please enter a valid number."}
    
    def search_stock(self, keyword):
        """Search for stocks based on keywords."""
        if not self.api_key:
            return {"success": False, "message": "API key is required for stock search."}
        
        self._throttle_api_calls()
        url = f"https://www.alphavantage.co/query?function=SYMBOL_SEARCH&keywords={keyword}&apikey={self.api_key}"
        
        try:
            response = requests.get(url)
            data = response.json()
            
            if "bestMatches" in data:
                results = []
                for match in data["bestMatches"]:
                    results.append({
                        "symbol": match["1. symbol"],
                        "name": match["2. name"],
                        "type": match["3. type"],
                        "region": match["4. region"],
                        "currency": match["8. currency"]
                    })
                return {"success": True, "results": results}
            else:
                return {"success": False, "message": data.get("Note", "No results found or API error")}
        except Exception as e:
            return {"success": False, "message": f"Error searching for stocks: {str(e)}"}
    
    def get_stock_price(self, symbol):
        """Get current stock price from Alpha Vantage API."""
        if not self.api_key:
            # Use mock data if no API key
            import random
            return round(random.uniform(50, 500), 2)
        
        self._throttle_api_calls()
        url = f"https://www.alphavantage.co/query?function=GLOBAL_QUOTE&symbol={symbol}&apikey={self.api_key}"
        try:
            response = requests.get(url)
            data = response.json()
            
            if "Global Quote" in data and "05. price" in data["Global Quote"]:
                return float(data["Global Quote"]["05. price"])
            else:
                print(f"Error fetching price for {symbol}: {data.get('Note', 'Unknown error')}")
                return None
        except Exception as e:
            print(f"Error fetching stock price for {symbol}: {e}")
            return None
    
    def get_stock_info(self, symbol):
        """Get detailed information about a stock."""
        if not self.api_key:
            return {"success": False, "message": "API key is required for stock information."}
        
        self._throttle_api_calls()
        url = f"https://www.alphavantage.co/query?function=OVERVIEW&symbol={symbol}&apikey={self.api_key}"
        
        try:
            response = requests.get(url)
            data = response.json()
            
            if "Symbol" in data:
                return {"success": True, "info": data}
            else:
                return {"success": False, "message": data.get("Note", "Stock information not found or API error")}
        except Exception as e:
            return {"success": False, "message": f"Error fetching stock information: {str(e)}"}
    
    def buy_stock(self, symbol, shares, price=None):
        """Buy stocks and add them to the portfolio."""
        try:
            symbol = symbol.upper()
            shares = float(shares)
            
            if shares <= 0:
                return {"success": False, "message": "Number of shares must be greater than zero."}
            
            # Get current price if not provided
            if price is None:
                price = self.get_stock_price(symbol)
                if price is None:
                    return {"success": False, "message": f"Could not fetch current price for {symbol}."}
            else:
                price = float(price)
            
            total_cost = price * shares
            
            # Check if we have enough cash
            if total_cost > self.portfolio["cash"]:
                return {
                    "success": False, 
                    "message": f"Insufficient funds. Cost: ${total_cost:.2f}, Available: ${self.portfolio['cash']:.2f}"
                }
            
            # Update cash
            self.portfolio["cash"] -= total_cost
            
            # Update portfolio
            if symbol in self.portfolio["stocks"]:
                # Calculate new average cost
                current_shares = self.portfolio["stocks"][symbol]["shares"]
                current_cost = self.portfolio["stocks"][symbol]["average_cost"]
                total_shares = current_shares + shares
                new_average_cost = ((current_shares * current_cost) + (shares * price)) / total_shares
                
                self.portfolio["stocks"][symbol]["shares"] = total_shares
                self.portfolio["stocks"][symbol]["average_cost"] = new_average_cost
            else:
                self.portfolio["stocks"][symbol] = {
                    "shares": shares,
                    "average_cost": price
                }
            
            # Record transaction
            self.portfolio["transactions"].append({
                "type": "buy",
                "symbol": symbol,
                "shares": shares,
                "price": price,
                "total": total_cost,
                "date": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            })
            
            self._save_portfolio()
            return {
                "success": True, 
                "message": f"Bought {shares} shares of {symbol} at ${price:.2f} per share (Total: ${total_cost:.2f})"
            }
        except ValueError:
            return {"success": False, "message": "Invalid input format. Please check your values."}
    
    def sell_stock(self, symbol, shares, price=None):
        """Sell stocks from the portfolio."""
        try:
            symbol = symbol.upper()
            shares = float(shares)
            
            if shares <= 0:
                return {"success": False, "message": "Number of shares must be greater than zero."}
            
            # Check if we have the stock and enough shares
            if symbol not in self.portfolio["stocks"]:
                return {"success": False, "message": f"You don't own any shares of {symbol}"}
            
            if shares > self.portfolio["stocks"][symbol]["shares"]:
                return {
                    "success": False, 
                    "message": f"You only have {self.portfolio['stocks'][symbol]['shares']} shares of {symbol}"
                }
            
            # Get current price if not provided
            if price is None:
                price = self.get_stock_price(symbol)
                if price is None:
                    return {"success": False, "message": f"Could not fetch current price for {symbol}."}
            else:
                price = float(price)
            
            total_value = price * shares
            
            # Update cash
            self.portfolio["cash"] += total_value
            
            # Update portfolio
            self.portfolio["stocks"][symbol]["shares"] -= shares
            
            # Remove stock if no shares left
            if self.portfolio["stocks"][symbol]["shares"] == 0:
                del self.portfolio["stocks"][symbol]
            
            # Record transaction
            self.portfolio["transactions"].append({
                "type": "sell",
                "symbol": symbol,
                "shares": shares,
                "price": price,
                "total": total_value,
                "date": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            })
            
            self._save_portfolio()
            return {
                "success": True, 
                "message": f"Sold {shares} shares of {symbol} at ${price:.2f} per share (Total: ${total_value:.2f})"
            }
        except ValueError:
            return {"success": False, "message": "Invalid input format. Please check your values."}
    
    def get_historical_data(self, symbol, days=30):
        """Get historical stock data for the specified symbol."""
        if not self.api_key:
            # Generate mock data if no API key
            dates = [(datetime.now() - timedelta(days=i)).strftime('%Y-%m-%d') for i in range(days, 0, -1)]
            import random
            starting_price = random.uniform(50, 500)
            prices = [round(starting_price * (1 + random.uniform(-0.05, 0.05) * i), 2) for i in range(days)]
            return pd.DataFrame({'date': dates, 'close': prices})
        
        end_date = datetime.now()
        start_date = end_date - timedelta(days=days)
        
        self._throttle_api_calls()
        url = f"https://www.alphavantage.co/query?function=TIME_SERIES_DAILY&symbol={symbol}&outputsize=full&apikey={self.api_key}"
        
        try:
            response = requests.get(url)
            data = response.json()
            
            if "Time Series (Daily)" in data:
                time_series = data["Time Series (Daily)"]
                df = pd.DataFrame(time_series).T
                df.index = pd.to_datetime(df.index)
                df = df.sort_index()
                
                # Rename columns and convert to numeric
                df.columns = ['open', 'high', 'low', 'close', 'volume']
                for col in df.columns:
                    df[col] = pd.to_numeric(df[col])
                
                # Filter by date range
                df = df[(df.index >= start_date.strftime('%Y-%m-%d')) & 
                        (df.index <= end_date.strftime('%Y-%m-%d'))]
                
                # Reset index to make date a column
                df = df.reset_index()
                df.rename(columns={'index': 'date'}, inplace=True)
                
                return df
            else:
                print(f"Error fetching historical data for {symbol}: {data.get('Note', 'Unknown error')}")
                return None
                
        except Exception as e:
            print(f"Error fetching historical data for {symbol}: {e}")
            return None
    
    def get_portfolio_summary(self):
        """Get a summary of the current portfolio status."""
        if not self.portfolio["stocks"] and self.portfolio["cash"] == 0:
            return {
                "cash": 0,
                "total_value": 0,
                "total_cost": 0,
                "total_gain_loss": 0,
                "total_gain_loss_pct": 0,
                "stocks": []
            }
        
        # Fetch current prices and calculate values
        portfolio_data = []
        total_value = self.portfolio["cash"]
        total_cost = 0
        
        for symbol, data in self.portfolio["stocks"].items():
            shares = data["shares"]
            avg_cost = data["average_cost"]
            cost_basis = shares * avg_cost
            total_cost += cost_basis
            
            current_price = self.get_stock_price(symbol)
            if current_price is None:
                current_price = avg_cost  # Use average cost if can't get current price
            
            current_value = shares * current_price
            total_value += current_value
            
            gain_loss = current_value - cost_basis
            gain_loss_pct = (gain_loss / cost_basis) * 100 if cost_basis > 0 else 0
            
            portfolio_data.append({
                "symbol": symbol,
                "shares": shares,
                "avg_cost": avg_cost,
                "cost_basis": cost_basis,
                "current_price": current_price,
                "current_value": current_value,
                "gain_loss": gain_loss,
                "gain_loss_pct": gain_loss_pct
            })
        
        # Sort by value (descending)
        portfolio_data.sort(key=lambda x: x["current_value"], reverse=True)
        
        # Calculate totals
        total_gain_loss = total_value - total_cost - self.portfolio["cash"]
        total_gain_loss_pct = (total_gain_loss / total_cost) * 100 if total_cost > 0 else 0
        
        return {
            "cash": self.portfolio["cash"],
            "total_value": total_value,
            "total_cost": total_cost,
            "total_gain_loss": total_gain_loss,
            "total_gain_loss_pct": total_gain_loss_pct,
            "stocks": portfolio_data
        }
    
    def get_transactions(self, limit=None, transaction_type=None):
        """Get transaction history with optional filtering."""
        transactions = self.portfolio["transactions"]
        
        if transaction_type:
            transactions = [t for t in transactions if t["type"] == transaction_type]
        
        # Sort transactions by date (newest first)
        transactions = sorted(transactions, key=lambda x: x["date"], reverse=True)
        
        if limit:
            transactions = transactions[:limit]
            
        return transactions
    
    def plot_portfolio_history(self, days=30):
        """Plot the historical performance of the portfolio and return the plot as a base64 string."""
        if not self.portfolio["stocks"]:
            return None
        
        end_date = datetime.now()
        start_date = end_date - timedelta(days=days)
        
        date_range = pd.date_range(start=start_date, end=end_date)
        portfolio_history = pd.DataFrame(index=date_range)
        portfolio_history.index.name = 'date'
        portfolio_history['total_value'] = 0
        
        # Add cash to total value
        portfolio_history['total_value'] += self.portfolio["cash"]
        
        # Process each stock
        for symbol, data in self.portfolio["stocks"].items():
            shares = data["shares"]
            historical_data = self.get_historical_data(symbol, days=days)
            
            if historical_data is not None:
                historical_data['date'] = pd.to_datetime(historical_data['date'])
                historical_data.set_index('date', inplace=True)
                
                # Make sure the index is unique
                historical_data = historical_data[~historical_data.index.duplicated(keep='first')]
                
                # Reindex to full date range and forward fill
                stock_data = pd.DataFrame(index=date_range)
                stock_data['close'] = historical_data['close'].reindex(date_range).ffill().bfill()
                
                # Calculate stock value for each day
                stock_data['value'] = stock_data['close'] * shares
                
                # Add to portfolio total
                portfolio_history['total_value'] += stock_data['value']
                
                # Store individual stock data
                portfolio_history[f'{symbol}_value'] = stock_data['value']
                portfolio_history[f'{symbol}_price'] = stock_data['close']
        
        # Create the plot
        fig = Figure(figsize=(10, 6))
        ax = fig.add_subplot(111)
        
        # Plot the total portfolio value
        ax.plot(portfolio_history.index, portfolio_history['total_value'], 'b-', linewidth=2, label='Total Portfolio Value')
        
        # Format the plot
        ax.set_title('Portfolio Value Over Time')
        ax.set_xlabel('Date')
        ax.set_ylabel('Value ($)')
        ax.grid(True, linestyle='--', alpha=0.7)
        fig.autofmt_xdate()  # Rotate date labels
        
        # Add legend
        ax.legend()
        
        # Convert plot to PNG image
        canvas = FigureCanvas(fig)
        buf = io.BytesIO()
        canvas.print_png(buf)
        buf.seek(0)
        
        # Convert PNG to base64 string
        img_str = base64.b64encode(buf.read()).decode('utf-8')
        
        return img_str
    
    def plot_asset_allocation(self):
        """Plot the asset allocation of the portfolio and return the plot as a base64 string."""
        if not self.portfolio["stocks"]:
            return None
        
        # Calculate current value of each position
        values = []
        labels = []
        
        total_value = self.portfolio["cash"]
        values.append(self.portfolio["cash"])
        labels.append("Cash")
        
        for symbol, data in self.portfolio["stocks"].items():
            shares = data["shares"]
            current_price = self.get_stock_price(symbol)
            if current_price is None:
                current_price = data["average_cost"]
            
            stock_value = shares * current_price
            total_value += stock_value
            
            values.append(stock_value)
            labels.append(symbol)
        
        # Calculate percentages
        percentages = [100 * v / total_value for v in values]
        
        # Create the pie chart
        fig = Figure(figsize=(8, 8))
        ax = fig.add_subplot(111)
        
        # Create pie chart with percentages
        wedges, texts, autotexts = ax.pie(
            values, 
            labels=labels, 
            autopct='%1.1f%%',
            startangle=90,
            wedgeprops={'edgecolor': 'w', 'linewidth': 1}
        )
        
        # Equal aspect ratio ensures that pie is drawn as a circle
        ax.axis('equal')
        ax.set_title('Portfolio Asset Allocation')
        
        # Convert plot to PNG image
        canvas = FigureCanvas(fig)
        buf = io.BytesIO()
        canvas.print_png(buf)
        buf.seek(0)
        
        # Convert PNG to base64 string
        img_str = base64.b64encode(buf.read()).decode('utf-8')
        
        return img_str
    
    def analyze_performance(self, benchmark=None, days=90):
        """Analyze portfolio performance compared to a benchmark."""
        if not self.portfolio["stocks"]:
            return {
                "success": False,
                "message": "No stocks in portfolio to analyze."
            }
        
        end_date = datetime.now()
        start_date = end_date - timedelta(days=days)
        
        # Get portfolio history
        date_range = pd.date_range(start=start_date, end=end_date)
        portfolio_history = pd.DataFrame(index=date_range)
        portfolio_history.index.name = 'date'
        portfolio_history['total_value'] = self.portfolio["cash"]
        
        # Track if we have any valid historical data
        has_valid_data = False
        
        # Process each stock
        for symbol, data in self.portfolio["stocks"].items():
            shares = data["shares"]
            historical_data = self.get_historical_data(symbol, days=days)
            
            if historical_data is not None:
                has_valid_data = True
                historical_data['date'] = pd.to_datetime(historical_data['date'])
                historical_data.set_index('date', inplace=True)
                
                # Make sure the index is unique
                historical_data = historical_data[~historical_data.index.duplicated(keep='first')]
                
                # Reindex to full date range and forward fill
                stock_data = pd.DataFrame(index=date_range)
                stock_data['close'] = historical_data['close'].reindex(date_range).ffill().bfill()
                
                # Calculate stock value for each day
                stock_data['value'] = stock_data['close'] * shares
                
                # Add to portfolio total
                portfolio_history['total_value'] += stock_data['value']
        
        if not has_valid_data:
            return {
                "success": False,
                "message": "Could not retrieve historical data for portfolio analysis."
            }
        
        # Calculate daily returns
        portfolio_history['daily_return'] = portfolio_history['total_value'].pct_change()
        
        # Get benchmark data if specified
        if benchmark:
            benchmark_data = self.get_historical_data(benchmark, days=days)
            if benchmark_data is not None:
                benchmark_data['date'] = pd.to_datetime(benchmark_data['date'])
                benchmark_data.set_index('date', inplace=True)
                
                # Reindex to match portfolio dates
                benchmark_prices = benchmark_data['close'].reindex(date_range).ffill().bfill()
                portfolio_history['benchmark'] = benchmark_prices
                portfolio_history['benchmark_return'] = portfolio_history['benchmark'].pct_change()
        
        # Calculate performance metrics
        portfolio_return = (portfolio_history['total_value'].iloc[-1] / portfolio_history['total_value'].iloc[0]) - 1
        annual_return = (1 + portfolio_return) ** (365 / days) - 1
        
        # Volatility (annualized standard deviation of daily returns)
        volatility = portfolio_history['daily_return'].std() * np.sqrt(252)  # 252 trading days in a year
        
        # Sharpe ratio (assuming risk-free rate of 0.01)
        risk_free_rate = 0.01
        sharpe_ratio = (annual_return - risk_free_rate) / volatility if volatility != 0 else 0
        
        # Maximum drawdown
        portfolio_history['cummax'] = portfolio_history['total_value'].cummax()
        portfolio_history['drawdown'] = (portfolio_history['total_value'] - portfolio_history['cummax']) / portfolio_history['cummax']
        max_drawdown = portfolio_history['drawdown'].min()
        
        metrics = {
            "success": True,
            "total_return": portfolio_return * 100,  # As percentage
            "annualized_return": annual_return * 100,  # As percentage
            "volatility": volatility * 100,  # As percentage
            "sharpe_ratio": sharpe_ratio,
            "max_drawdown": max_drawdown * 100,  # As percentage
            "start_value": portfolio_history['total_value'].iloc[0],
            "end_value": portfolio_history['total_value'].iloc[-1]
        }
        
        # Add benchmark comparison if available
        if benchmark and 'benchmark_return' in portfolio_history:
            benchmark_return = (portfolio_history['benchmark'].iloc[-1] / portfolio_history['benchmark'].iloc[0]) - 1
            benchmark_annual_return = (1 + benchmark_return) ** (365 / days) - 1
            benchmark_volatility = portfolio_history['benchmark_return'].std() * np.sqrt(252)
            benchmark_sharpe = (benchmark_annual_return - risk_free_rate) / benchmark_volatility if benchmark_volatility != 0 else 0
            
            # Calculate beta (portfolio return vs benchmark return)
            covariance = portfolio_history['daily_return'].cov(portfolio_history['benchmark_return'])
            benchmark_variance = portfolio_history['benchmark_return'].var()
            beta = covariance / benchmark_variance if benchmark_variance != 0 else 1
            
            # Alpha (excess return over what would be predicted by beta)
            alpha = annual_return - (risk_free_rate + beta * (benchmark_annual_return - risk_free_rate))
            
            metrics.update({
                "benchmark_symbol": benchmark,
                "benchmark_return": benchmark_return * 100,
                "benchmark_annual_return": benchmark_annual_return * 100,
                "alpha": alpha * 100,
                "beta": beta
            })
            
            # Plot performance comparison
            fig = Figure(figsize=(10, 6))
            ax = fig.add_subplot(111)
            
            # Normalize both series to start at 100
            norm_portfolio = 100 * portfolio_history['total_value'] / portfolio_history['total_value'].iloc[0]
            norm_benchmark = 100 * portfolio_history['benchmark'] / portfolio_history['benchmark'].iloc[0]
            
            ax.plot(portfolio_history.index, norm_portfolio, 'b-', linewidth=2, label='Portfolio')
            ax.plot(portfolio_history.index, norm_benchmark, 'r--', linewidth=2, label=f'Benchmark ({benchmark})')
            
            ax.set_title('Portfolio vs Benchmark Performance')
            ax.set_xlabel('Date')
            ax.set_ylabel('Normalized Value (Starting at 100)')
            ax.grid(True, linestyle='--', alpha=0.7)
            ax.legend()
            fig.autofmt_xdate()
            
            # Convert plot to PNG image
            canvas = FigureCanvas(fig)
            buf = io.BytesIO()
            canvas.print_png(buf)
            buf.seek(0)
            
            # Convert PNG to base64 string
            img_str = base64.b64encode(buf.read()).decode('utf-8')
            metrics["comparison_chart"] = img_str
        
        return metrics
